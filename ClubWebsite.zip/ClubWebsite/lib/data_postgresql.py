import psycopg2, psycopg2.extras, uuid, hashlib
from lib.config import *

def connectToPostgres():
    connectionString = 'dbname = %s user = %s password = %s host = %s' % (postgres_database, postgres_user, postgres_password, postgres_host)
    try:
        return psycopg2.connect(connectionString)
    except Exception as e:
        print(type(e))
        print(e)
        print("Can't connect to database")
        return None
        
def execute_query(query, conn, select = True, args = None):
    cur = conn.cursor(cursor_factory = psycopg2.extras.DictCursor)
    results = None
    try:
        q = cur.mogrify(query, args)
        cur.execute(q)
        if select:
            results = cur.fetchall()
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(type(e))
        print(e)
    cur.close()
    return results
    
def get_all_reg():
    conn = connectToPostgres()
    if conn == None:
        return None
    qString = "select firstname, lastname, ranked from duelists"
    results = execute_query(qString, conn)
    conn.close()
    return results
    
def execute_register(fname, lname, email, saber, form, ranked):
    conn = connectToPostgres()
    if conn == None:
        return None
    
    qString = "insert into duelists values (%s, %s, %s, %s, %s, %s)"
    execute_query(qString, conn, select = False, args = (fname, lname, saber, form, ranked, email))
    conn.close()
    
def execute_adduser(u, p, f, l, m, s, c, st):
    conn = connectToPostgres()
    if conn == None:
        return None
    qString = "insert into users values (%s, %s, %s, %s, %s, %s, %s, %s)"
    execute_query(qString, conn, select = False, args = (u, p, f, l, m, s, c, st))
    conn.close()
    
def execute_login(u, p):
    conn = connectToPostgres()
    if conn == None:
        return None
    qString = "select * from users where username = (%s) and password = (%s)"
    results = execute_query(qString, conn, args = (u, p))
    conn.close()
    return results
    
def hash_password(p):
    salt = 'c66a729bdc9c48d08cc05998ef9bb198'
    return hashlib.sha256(salt.encode() + p.encode()).hexdigest() + ':' + salt
    
def get_tourneys(state):
    conn = connectToPostgres()
    if conn == None:
        return None
    qString = "select division, city, state, tdate from tourneys where state = (%s)"
    results = execute_query(qString, conn, args = (state,))
    print(results)
    conn.close()
    return results
    
def get_famous(term):
    conn = connectToPostgres()
    if conn == None:
        return None
    qString = "select title, name, saberstyle, combatform from famous where title like (%s) or name like (%s) or saberstyle like (%s) or combatform like (%s)"
    results = execute_query(qString, conn, args = (term, term, term, term))
    conn.close()
    return results
    
def add_message(u, m):
    conn = connectToPostgres()
    if conn == None:
        return None
    qString = "insert into messages values (%s, %s, %s)"
    execute_query(qString, conn, select = False, args = (u, m, "CURRENT_TIMESTAMP"))
    conn.close()
    
def get_messages():
    conn = connectToPostgres()
    if conn == None:
        return None
    qString = "select username, message from messages"
    results = execute_query(qString, conn)
    conn.close()
    return results