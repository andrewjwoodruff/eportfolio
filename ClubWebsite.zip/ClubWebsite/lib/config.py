postgres_user = "lsc_man"
postgres_password = "NotTheYounglings"
postgres_database = "registerlist"
postgres_host = "localhost"

