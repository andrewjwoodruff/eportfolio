import os, uuid
from lib.config import *
from lib import data_postgresql as pg
from flask import Flask, render_template, request, session
from flask_socketio import SocketIO, emit
app = Flask(__name__)
app.secret_key = os.urandom(24).encode('hex')
chat = Flask(__name__, static_url_path = '')
chat.config['SECRET_KEY'] = 'secret!'

socketio = SocketIO(chat)

messages = [{'text': 'Booting system', 'name': 'Bot'},
            {'text': 'Chat is not live!', 'name': 'Bot'}]
            
users = {}

@socketio.on('connect', namespace = '/chat')
def makeConnection():
    session['uuid'] = uuid.uuid1()
    session['username'] = 'New User'
    print('connected')
    users[session['uuid']] = {'username': 'New User'}
    messages = pg.get_messages()
    for message in messages:
        print(message)
        emit('message', message)

@socketio.on('identify', namespace = '/chat')
def identify(name):
    print('identify ' + name)
    users[session['uuid']] = {'username': name}

@socketio.on('message', namespace = '/chat')
def new_message(message):
    temp = {'text': message, 'name': users[session['uuid']]['username']}
    print(temp)
    messages.append(temp)
    pg.add_message(users[session['uuid']], message)
    emit('message', temp, broadcast = True)

@app.route('/')
@app.route('/index')
def mainIndex():
    tournementPractice = True
    meeting = {'date': '29 March', 'time': '1930', 'loc': 'sub-basement of Trinkle'}
    return render_template('index.html', meeting=meeting, tournementPractice=tournementPractice)
    

@app.route('/register', methods = ['GET', 'POST'])
def register():
    if request.method == 'POST':
        if "ranked" in request.form:
            ranked = True
        else:
            ranked = False
        pg.execute_register(request.form['firstname'], request.form['lastname'], request.form['email'], request.form['saberstyle'], request.form['combatform'], ranked)
    results = pg.get_all_reg()
    return render_template('register.html', registered = results)
    
    
@app.route('/login', methods = ['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['submit'] == "Sign Up":
            pg.execute_adduser(request.form['username'], pg.hash_password(request.form['password']), request.form['firstname'], request.form['lastname'], request.form['email'], request.form['saberstyle'], request.form['combatform'], request.form['state'])
            user = pg.execute_login(request.form['username'], pg.hash_password(request.form['password']))
            if not user:
                return render_template('login.html', Failed = True)
            else:
                session['username'] = user[0]['username']
                session['state'] = user[0]['state']
                session['loggedin'] = True
                return render_template('login.html', Failed = False)
        elif request.form['submit'] == "Login":
            user = pg.execute_login(request.form['username'], pg.hash_password(request.form['password']))
            if not user:
                return render_template('login.html', Failed = True)
            else:
                session['username'] = user[0]['username']
                session['state'] = user[0]['state']
                session['loggedin'] = True
                return render_template('login.html', Failed = False)
    return render_template('login.html', Failed = False)
    
@app.route('/search', methods = ['GET', 'POST'])
def search():
    if request.method == 'POST':
        if request.form['searchterm'] == "tournements":
            try:
                results = pg.get_tourneys(session['state'])
            except:
                results = pg.get_tourneys('VA')
            if results == None:
                return render_template('search.html', noresults = True)
            return render_template('search.html', searchtype = "tournements", results = results, noresults = False)
        else:
            results = pg.get_famous(request.form['searchterm'])
            if results == None:
                return render_template('search.html', noresults = True)
            return render_template('search.html', searchtype = "famous", results = results, noresults = False)
    return render_template('search.html', searchtype = None)

@app.route('/history')
def history():
    return render_template('history.html')

@app.route('/vlog')
def vlog():
    videos = [{'title': 'Freestyle Encounters', 'link': 'eJKNVY9dWwM', 'desc': 'A collection of duels from the 2012 Italian Nationals'},
            {'title': 'Top 10 Lightsaber Battles', 'link': '7MAVG2BfTHc', 'desc': 'WatchMojo\'s top 10 ranking of Lightsaber Battles in the Movies and TV series'},
            {'title': 'Exhibition Duel at 2015 World Fencing Championships', 'link': 'T4is7h_cgzI', 'desc': 'A duel performed during the 2015 Fencing Senior World Championships in Moscow. The duelists were titled fencing athletes in various Russian championships.'},
            {'title': 'Evolution of Lightsaber Duels', 'link': '4vGjNnZhJFI', 'desc': 'A documentary on the evolution and history of lightsaber duels.'}]
    
    return render_template('vlog.html', videos=videos)
    
@app.route('/members')
def members():
    winner = "Luke Skywalker"
    return render_template('members.html', leader=winner)
    
@app.route('/chat')
def chat():
    return app.send_static_file('chat.html')
    
# start the server
if __name__ == '__main__':
    #socketio.run(app, host='0.0.0.0', port=80, debug=True)
    socketio.run(app, host=os.getenv('IP', '0.0.0.0'), port=int(os.getenv('PORT', 8080)), debug=True)
