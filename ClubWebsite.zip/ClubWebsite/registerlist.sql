drop database if exists registerlist;
create database registerlist;
\c registerlist;


drop table if exists duelists;
create table duelists (
    firstname varchar(25) not null,
    lastname varchar(25) not null,
    saberstyle varchar(15) not null,
    combatform varchar(15) not null,
    ranked boolean default False,
    email varchar(50) not null
);

insert into duelists values ('Obi-wan', 'Kenobi', 'Single Blade', 'Soresu', 'True', 'oldben@gmail.com');
insert into duelists values ('Kanan', 'Jarrus', 'Single Blade', 'Shien/Djem So', 'False', 'rebeljedi@gmail.com');

drop table if exists users;
create table users (
    username varchar(25) not null,
    password varchar(100) not null,
    firstname varchar(25) not null,
    lastname varchar(25) not null,
    email varchar(50) not null,
    saberstyle varchar(15) not null,
    combatform varchar(15) not null,
    state varchar(2) not null,
    primary key (username)
);

drop table if exists tourneys;
create table tourneys (
    id serial not null,
    division varchar(15) not null,
    city varchar(25) not null,
    state varchar(2) not null,
    tdate date not null
);

insert into tourneys (division, city, state, tdate) values ('Division 1','New York','NY', '03-26-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Buffalo','NY', '03-28-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Los Angeles','CA', '04-06-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Chicago','IL', '04-06-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Houston','TX', '04-13-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Philadelphia','PA', '04-12-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Phoenix','AZ', '06-15-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','San Diego','CA', '08-08-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Dallas','TX', '03-23-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','San Antonio','TX', '06-27-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Detroit','MI', '10-23-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','San Jose','CA', '03-28-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Indianapolis','IN', '04-03-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','San Francisco','CA', '04-04-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Jacksonville','FL', '04-05-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Columbus','OH', '04-06-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Austin','TX', '04-07-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Baltimore','MD', '04-08-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Memphis','TN', '04-09-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Milwaukee','WI', '04-10-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Boston','MA', '04-11-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Washington','DC', '04-12-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Nashville','TN', '04-13-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','El Paso','TX', '04-14-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Seattle','WA', '04-15-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Denver','CO', '04-16-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Charlotte','NC', '04-17-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Fort Worth','TX', '04-18-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Portland','OR', '04-19-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Oklahoma City','OK', '04-20-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Tuscon','AZ', '04-21-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','New Orleans','LA', '04-22-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Las Vegas','NV', '04-23-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Cleveland','OH', '04-24-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Long Beach','CA', '04-25-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Albuquerque','NM', '04-27-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Kansas City','MO', '04-28-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Fresno','CA', '04-29-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Virginia Beach','VA', '04-30-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Atlanta','GA', '05-01-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Sacramento','CA', '05-02-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Oakland','CA', '05-03-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Mesa','AZ', '05-04-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Tulsa','OK', '05-05-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Omaha','NE', '05-06-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Minneapolis','MN', '05-07-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Honolulu','HI', '05-08-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Miami','FL', '05-09-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Colorado Springs','CO', '05-10-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Saint Louis','MO', '05-11-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Wichita','KS', '05-12-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Santa Ana','CA', '05-13-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Pittsburgh','PA', '05-14-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Arlington','TX', '05-15-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Cincinnati','OH', '05-16-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Anaheim','CA', '05-17-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Toledo','OH', '05-18-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Tampa','FL', '05-19-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Saint Paul','MN', '05-20-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Raleigh','NC', '05-21-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Newark','NJ', '05-22-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Lexington-Fayette','KY', '05-23-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Anchorage','AK', '05-24-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Louisville','KY', '05-25-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Birmingham','AL', '05-26-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Jersey City','NJ', '05-27-17');
insert into tourneys (division, city, state, tdate) values ('Division 1','Norfolk','VA', '05-28-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Richmond','VA', '05-29-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Salt Lake City','UT', '05-30-17');
insert into tourneys (division, city, state, tdate) values ('Division 3','Savannah','GA', '06-01-17');
insert into tourneys (division, city, state, tdate) values ('Division 2','Kansas City','KS', '06-02-17');


drop table if exists famous;
create table famous (
    id serial not null,
    title varchar(15),
    name varchar(25),
    saberstyle varchar(20),
    combatform varchar(15)
);

insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Obi-wan Kenobi', 'Single Blade', 'Soresu');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Knight','Anakin Skywalker', 'Single Blade', 'Shien');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Luke Skywalker', 'Single Blade', 'Shien');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Padawan','Rey', 'Single Blade', ' ');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Kit Fisto', 'Single Blade', 'Shii-Cho');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Qui-Gon Jinn', 'Single Blade', 'Ataru');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Plo Koon', 'Single Blade', 'Ataru');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Aayla Secura', 'Single Blade', 'Shien');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Shaak Ti', 'Single Blade', 'Makashi');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Luminara Unduli', 'Single Blade', 'Soresu');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Mace Windu', 'Single Blade', 'Vaapad');
insert into famous (title, name, saberstyle, combatform) values ('Sith Lord','Darth Tyranus', 'Single Blade', 'Makashi');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master','Count Dooku', 'Single Blade', 'Makashi');
insert into famous (title, name, saberstyle, combatform) values ('Sith Lord','Darth Vader', 'Single Blade', 'Djem So');
insert into famous (title, name, saberstyle, combatform) values ('Sith Lord', 'Darth Maul', 'Double-Sided Blade', 'Juyo');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Knight', 'Kyle Katarn', 'Single Blade', 'Djem So');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Padawan', 'Ahsoka Tano', 'Dual Blades', 'Shien');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Knight', 'Kanan Jarrus', 'Single Blade', 'Soresu');
insert into famous (title, name, saberstyle, combatform) values ('Sith Apprentice', 'Galen Marek', 'Single Blade', 'Juyo');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Knight', 'Zayne Carrick', 'Single Blade', 'Shii-Cho');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Master', 'Yoda', 'Single Blade', 'Niman');
insert into famous (title, name, saberstyle, combatform) values ('Jedi Knight', 'Bastila Shan', 'Double-Sided Blade', 'Makashi');


drop table if exists messages;
create table messages {
    username varchar(25) not null,
    message varchar(200),
    time date not null,
}