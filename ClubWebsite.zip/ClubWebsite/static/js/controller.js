var ChatApp = angular.module('ChatApp', []);

ChatApp.controller('ChatController', function($scope){
   var socket = io.connect('https://' + document.domain + ':' + location.port + '/chat');
   
   $scope.messages = [];
   $scope.name = '';
   $scope.text = '';
   
   socket.on('message', function(msg){
      console.log(msg);
      $scope.messages.push(msg);
      $scope.$apply();
      var elem = document.getElementById('msgpane');
      elem.scrollTop = elem.scrollHeight;
      
   });
   
   socket.on('connect', function(){
       console.log('connected');
   });
   
   $scope.setName = function setName(){
     socket.emit('identify', $scope.name)  
   };
   
   $scope.send = function send(){
     console.log('Sending message: ', $scope.text);
     socket.emit('message', $scope.text);
     $scope.text = '';
     
   };
   
});