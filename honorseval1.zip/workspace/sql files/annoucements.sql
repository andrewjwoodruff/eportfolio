drop table if exists announcements;

create table announcements (
    id serial not null,
    date date,
    time time,
    title text,
    message text,
    primary key(id)
    
);

grant all on announcements to manager;
