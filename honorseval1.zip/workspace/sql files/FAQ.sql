drop table if exists FAQ;

create table FAQ (
    id serial not null,
    question text,
    answer text,
    primary key(id)
    
);

grant all on FAQ to manager;